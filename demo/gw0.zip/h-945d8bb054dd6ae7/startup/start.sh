#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 147.210.0.2/24
