#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 192.168.0.3/24
