#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 172.16.0.2/24
route add default gw 172.16.0.1
