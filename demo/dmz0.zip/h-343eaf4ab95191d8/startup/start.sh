#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 147.210.0.1/24
ifconfig eth1 192.168.0.1/24
ifconfig eth2 192.168.1.1/24
ifconfig eth3 172.16.0.1/24
echo 1 > /proc/sys/net/ipv4/ip_forward
