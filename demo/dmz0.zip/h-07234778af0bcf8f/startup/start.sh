#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 192.168.1.2/24
route add default gw 192.168.1.1
