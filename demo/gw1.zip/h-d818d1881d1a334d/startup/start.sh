#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 147.210.0.1/24
ifconfig eth1 192.168.0.1/24
echo 1 > /proc/sys/net/ipv4/ip_forward
