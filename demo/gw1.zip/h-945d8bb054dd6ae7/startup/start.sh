#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 147.210.0.2/24
route add default gw 147.210.0.1
