#!/bin/sh
hostname @HOSTNAME@
ifconfig eth0 192.168.0.2/24
route add default gw 192.168.0.1
