#!/bin/bash

iptables -F
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

# catch-all rules to allow reply packets for established & related connections
iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT

# allow ICMP traffic from the local network
iptables -A FORWARD -p icmp -s 192.168.1.0/24 -j ACCEPT

